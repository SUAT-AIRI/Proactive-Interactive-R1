import argparse
import re
import json
from openai import OpenAI
from utils.model_client import ModelClient
import os
from tqdm import tqdm
from utils.load_dataset import load_dataset

system_prompt = (
    "Answer the given question. "
    "You must conduct reasoning inside <think> and </think> first every time you get new information. "
    "If you find you lack some knowledge or clarification is required, you can call a asking engine by <asking> query </asking> and it will return the requested information between <response> and </response>. "
    "You can ask as many times as your want. "
    "If you find no further external knowledge needed, present the final answer after </think>."
    )

user_trigger_prompt = ''' Please reason step by step, and put your final answer within \\boxed{}.'''

# 定义一个函数用于保存数据
def save_partial_output(dataset, output_file_path, processed_count):
    with open(output_file_path, "w") as f:
        json.dump(dataset, f, indent=4, ensure_ascii=False)
    print(f"已处理并保存 {processed_count} 条数据至 {output_file_path}")

def batch_run(args):
    print(args)
    
    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)
    
    file_name = args.input_file.split("/")[-1].split(".json")[0]

    # 修改文件名，标记为 human_interactive
    generation_output_file_path = os.path.join(
        args.output_dir, f"{args.model_name}_human_interactive_{file_name}_{args.question_key}_generation_result.json"
    )

    # evaluation_output_file_path = os.path.join(
    #     args.output_path, f"{args.model_name}_human_interactive_{file_name}_{args.question_key}_eval_result.json"
    # )

    # 加载数据
    dataset = load_dataset(args.input_file)[0:1]
    processed_count = 0
    error_count = 0

    # === 主循环 (改为单线程串行) ===
    # 因为需要人工在控制台输入，无法使用多线程并发
    for idx, item in tqdm(enumerate(dataset), total=len(dataset), desc="Processing Data"):
        try:
            if item.get("output"):
                processed_count += 1
                continue  # 跳过已处理

            print(f"\n{'='*20} 当前处理第 {idx+1} 条数据 {'='*20}")
            question = item['question']
            intend_question = item['user_intent']
            print(f"\n[Your Intend Question (Hidden to Assistant)]: {intend_question}")
            print(f"[Your Question To Assistant]: {question}\n")

            # 初始化模型客户端
            model_client = ModelClient(
                model_path=args.model_name,
                base_url=args.model_url,
                stop_tokens=["</asking>", "<｜end▁of▁sentence｜>"],
                reasoning_model=True,
            )

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question},
                {"role": "assistant", "content": model_client.completion},
            ]
            
            print(">>> Model Are Reasoning...")
            model_response = model_client.chat(messages=messages)
            # print(model_response)

            # 如果模型要求继续追问
            while model_client.stop_reason == "</asking>":
                # 提取模型想问的问题
                ask_match = re.search(r"<asking>(.*?)</asking>", model_response, re.DOTALL)
                if ask_match:
                    ask_content = ask_match.group(1).strip()
                    print(f"\n[Model Reasoning]: {model_response.split(f'<asking>{ask_content}</asking>')[0]}")
                    print(f"[Model Asking]: {ask_content}")
                    
                    # === 关键修改：等待真实用户输入 ===
                    print("-" * 50)
                    user_response = input("Please provide your response (Press Enter to send): ").strip()
                    print("-" * 50)
                    # ================================
                    

                    model_client.completion += f"\n<response>{user_response}</response>"
                    messages = [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": question + user_trigger_prompt},
                        {"role": "assistant", "content": model_client.completion},
                    ]
                    print(">>> Model Received Response, Continuing Reasoning...")
                    model_response = model_client.chat(messages=messages)
                    # print(f"[Model Again Response]: {model_response}\n")
                else:
                    # 如果匹配不到 asking 标签但停止原因是 asking，可能是格式错误，强制跳出
                    print("Warning: Detected asking stop reason but regex failed.")
                    break

            item["output"] = model_client.completion
            processed_count += 1
            
            # 打印最终结果预览
            print(f"\n[Model Final Output]:\n{model_client.completion.split('</think>')[-1]}")

            # 每处理 1 条就保存一次，防止人工输入过程中断丢失进度
            save_partial_output(dataset[:processed_count], generation_output_file_path, processed_count)

        except KeyboardInterrupt:
            print("\nUser manually interrupted the program. Saving processed data...")
            save_partial_output(dataset, generation_output_file_path, processed_count)
            exit()
        except Exception as e:
            error_count += 1
            print(f"Error processing item {idx}: {e}")

    # 保存全部
    save_partial_output(dataset, generation_output_file_path, processed_count)
    print(f"处理完成，共处理 {processed_count} 条数据，发生错误 {error_count} 次。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Interactive Generation with Human Input")
    parser.add_argument("--input_file", type=str, required=False, help="训练数据集路径", default="/home/chenxin/verl-interactive/datasets/mip/gsm8k.json")
    parser.add_argument("--model_url", type=str, required=False, help="模型URL", default="http://localhost:1136")
    parser.add_argument("--tokenizer_path", type=str, required=False, help="分词器路径", default="/home/chenxin/shared/models/deepseek-ai/DeepSeek-R1-Distill-Qwen-7B")
    parser.add_argument("--model_name", type=str, required=False, help="模型名称", default="Proactive-Interactive-R1-Math-7B")
    parser.add_argument("--question_key", type=str, required=False, help="问题字段名称", default="question")
    parser.add_argument("--output_dir", type=str, required=False, help="输出目录", default="results/")
    args = parser.parse_args()
    batch_run(args)